// jQuery(function() {
//   return $("#skill_search").autocomplete({
//     source: "/autocomplete"
//   });
// });
